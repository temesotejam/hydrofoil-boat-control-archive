#include "boat_protocol.h"

namespace boat {
uint32_t crc32(const uint8_t *d, size_t n) {
  uint32_t c = 0xffffffff;
  while (n--) {
    c ^= *d++;
    for (uint8_t i = 0; i < 8; i++)
      c = (c >> 1) ^ ((c & 1) ? 0xedb88320 : 0);
  }
  return ~c;
}

static size_t cobs(const uint8_t *in, size_t n, uint8_t *out) {
  size_t r = 0, codePos = 0;
  uint8_t code = 1;
  out[r++] = 0;
  for (size_t i = 0; i < n; i++) {
    if (in[i] == 0) {
      out[codePos] = code;
      code = 1;
      codePos = r++;
    } else {
      out[r++] = in[i];
      if (++code == 0xff) {
        out[codePos] = code;
        code = 1;
        codePos = r++;
      }
    }
  }
  out[codePos] = code;
  return r;
}

size_t encode(const Header &h, const uint8_t *p, uint8_t *out, size_t cap) {
  if (h.length > kMaxPayload || cap < kMaxEncoded)
    return 0;
  uint8_t raw[kMaxRaw];
  memcpy(raw, &h, sizeof(h));
  if (h.length)
    memcpy(raw + sizeof(h), p, h.length);
  uint32_t c = crc32(raw, sizeof(h) + h.length);
  memcpy(raw + sizeof(h) + h.length, &c, 4);
  size_t n = cobs(raw, sizeof(h) + h.length + 4, out);
  out[n++] = 0;
  return n;
}

bool Decoder::feed(uint8_t b, Frame &f) {
  if (b) {
    if (n_ >= sizeof(encoded_)) {
      n_ = 0;
      lengthErrors++;
    } else
      encoded_[n_++] = b;
    return false;
  }
  if (!n_)
    return false;
  uint8_t raw[kMaxRaw];
  size_t r = 0;
  for (size_t i = 0; i < n_;) {
    uint8_t code = encoded_[i++];
    if (!code || i + code - 1 > n_ + 1) {
      cobsErrors++;
      n_ = 0;
      return false;
    }
    for (uint8_t j = 1; j < code && i < n_; j++)
      raw[r++] = encoded_[i++];
    if (code < 0xff && i < n_)
      raw[r++] = 0;
  }
  n_ = 0;
  if (r < sizeof(Header) + 4) {
    lengthErrors++;
    return false;
  }
  memcpy(&f.header, raw, sizeof(Header));
  if (f.header.version != kVersion || f.header.length > kMaxPayload ||
      r != sizeof(Header) + f.header.length + 4) {
    lengthErrors++;
    return false;
  }
  uint32_t got;
  memcpy(&got, raw + sizeof(Header) + f.header.length, 4);
  if (got != crc32(raw, sizeof(Header) + f.header.length)) {
    crcErrors++;
    return false;
  }
  if (f.header.length)
    memcpy(f.payload, raw + sizeof(Header), f.header.length);
  return true;
}
}