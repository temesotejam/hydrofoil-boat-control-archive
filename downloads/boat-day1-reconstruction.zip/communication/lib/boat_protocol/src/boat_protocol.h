#pragma once
#ifdef ARDUINO
#include <Arduino.h>
#else
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#endif
namespace boat {
constexpr uint8_t kVersion = 1;
constexpr size_t kMaxPayload = 768, kMaxRaw = 800, kMaxEncoded = 820;
enum class Type : uint8_t {
  Hello = 1,
  BnoAccel = 2,
  BnoGyro = 3,
  BnoQuaternion = 4,
  TofFrame = 5,
  InaSample = 6,
  VescStatus = 7,
  ActuatorState = 8,
  SystemHealth = 9,
  Event = 10,
  TimeSyncReply = 11,
  GnssRaw = 12,
  GnssFix = 13,
  GnssStatus = 14,
  GnssNav = 15,
  GnssProcessResult = 16,
  CommandAck = 17,
  TimeSyncRequest = 18,
  LinkStatistics = 19,
  BnoMagnetic = 20,
  TimingDiagnostic = 21,
  EstimatedState = 22,
  P1Capture = 23,
  PrimaryImuSnapshot = 24,
  ProvisionalSystem = 25,
  CalibrationMarker = 26,
  Heartbeat = 32,
  Arm = 33,
  Disarm = 34,
  StartTest = 35,
  Stop = 36,
  Estop = 37,
  ClearEstop = 38,
  BenchmarkPrepare = 48,
  BenchmarkReady = 49,
  BenchmarkStart = 50,
  BenchmarkStop = 51,
  BenchmarkResult = 52,
  BenchmarkEvent = 53,
  SyntheticData = 54,
  BenchmarkAbort = 55,
  Reserved56 = 56,
  Reserved57 = 57,
  Reserved58 = 58,
  GnssNavV2 = 59,
  TimeSyncEstimate = 60,
  Reserved61 = 61,
  ControlOutput = 62,
  ControlSnapshot = 63,
  InaStatus = 64,
  VescTelemetry = 65,
  WaypointSet = 66,
  WaypointAck = 67,
  ControlModeCommand = 68,
  ManualCommand = 69,
  HeadingTarget = 70,
  ControlCommandAck = 71,
  RuntimeTuning = 72
};

struct __attribute__((packed)) Header {
  uint8_t version, type;
  uint16_t length;
  uint32_t sequence, bootId;
  uint64_t sourceUs;
  uint16_t flags;
};

struct Frame {
  Header header{};
  uint8_t payload[kMaxPayload]{};
  uint64_t uartRxUs = 0, logQueueUs = 0, sdTaskUs = 0;
};

struct __attribute__((packed)) BnoPayload {
  uint8_t kind, accuracy, sequence, reserved;
  uint64_t sensorUs, callbackUs, queuePushUs;
  float v[7];
};

struct __attribute__((packed)) PrimaryImuSnapshotPayload {
  uint64_t accelSensorUs, gyroSensorUs, magneticSensorUs;
  uint8_t accelAccuracy, gyroAccuracy, magneticAccuracy, reserved;
  float accel[3], gyro[3], magnetic[3];
};

struct __attribute__((packed)) ControlOutputPayload {
  uint64_t timestampUs;
  float leftFrontWing, rightFrontWing, rearYaw, propulsion;
  float leftPrelimit, rightPrelimit, rearYawPrelimit, propulsionPrelimit;
  float uHeight, uPitch, uRoll, targetCourseRad, courseErrorRad, waypointDistanceM;
  uint8_t waypointIndex, safety, stopReason, reservedControl, valid, reserved[3];
};

struct __attribute__((packed)) ControlSnapshotPayload {
  uint64_t timestampUs;
  uint32_t cycle, waypointRevision, gnssAgeUs, imuAgeUs, tofAgeUs;
  double latitudeDeg, longitudeDeg, targetWaypointLatitudeDeg, targetWaypointLongitudeDeg;
  float speedMps, gnssCourseRad, localNorthM, localEastM, targetBearingRad, courseErrorRad,
      waypointDistanceM;
  float rollRad, pitchRad, yawRad, rollRateRadS, pitchRateRadS, yawRateRadS;
  uint16_t tofRawMm;
  float tofFilteredM, heightErrorM, uHeight, uPitch, uRoll, uYaw, frontCommon, frontDifferential;
  float leftFrontWing, rightFrontWing, rearYaw, propulsion, leftPrelimit, rightPrelimit,
      rearYawPrelimit, propulsionPrelimit;
  uint8_t gnssValid, imuValid, tofValid, heightValid, waypointReached, outputValid, state,
      safetyReason, mode, activeWaypoint, reserved[2];
  float vescErpm;
  uint8_t yawControlActive, yawCriteriaMask, vescLowErpmWarning, reservedYaw;
};

struct __attribute__((packed)) InaStatusPayload {
  uint64_t timestampUs;
  uint32_t ageUs;
  float busVoltageV, shuntVoltageV, currentA, powerW;
  uint8_t valid, errorCode;
  uint16_t reserved;
};

struct __attribute__((packed)) VescTelemetryPayload {
  uint64_t timestampUs;
  uint32_t ageUs;
  float inputVoltageV, motorCurrentA, inputCurrentA, duty, erpm, mosTempC, motorTempC;
  int32_t tachometer;
  uint8_t valid, fault, reserved[2];
};

struct __attribute__((packed)) ActuatorStatePayload {
  uint64_t timestampUs;
  uint32_t pwmWrites, pwmErrors;
  uint16_t leftPulseUs, rightPulseUs, rearPulseUs;
  uint8_t motorRelayEnabled, enabledMask;
  float targetDuty, appliedDuty;
  uint8_t pcaReady, outputsEnabled, safetyState, controlMode;
};

struct __attribute__((packed)) SystemHealthPayload {
  uint64_t timestampUs;
  uint32_t flags;
  uint32_t imuAgeUs, tofAgeUs, gnssAgeUs, powerAgeUs, vescAgeUs;
  uint8_t safetyState, controlMode, stopReason, reserved;
};

struct __attribute__((packed)) WaypointGeo {
  double latitudeDeg, longitudeDeg;
};

struct __attribute__((packed)) WaypointSetPayload {
  uint32_t requestId, revision;
  uint8_t action, count, reserved[2];
  float reachRadiusM;
  WaypointGeo points[16];
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) WaypointAckPayload {
  uint32_t requestId, revision;
  uint8_t status, reason, activeIndex, count;
  uint32_t canonicalCrc;
};

enum ControlModeId : uint8_t {
  ControlManual = 0,
  ControlAttitudeAssist = 1,
  ControlHeadingHold = 2,
  ControlAutoWaypoint = 3,
  ControlWaypointOnly = 4
};

struct __attribute__((packed)) ControlModeCommandPayload {
  uint8_t protocolVersion, mode;
  uint16_t reserved;
  uint32_t requestId, commandSequence;
  uint64_t sourceUs;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) ManualCommandPayload {
  uint8_t protocolVersion, reserved[3];
  uint32_t requestId, commandSequence;
  uint64_t sourceUs;
  float leftFrontWing, rightFrontWing, rearYaw, propulsion;
  uint32_t canonicalCrc;
};

enum ManualOutputMask : uint8_t {
  ManualLeft = 1u << 0,
  ManualRight = 1u << 1,
  ManualRear = 1u << 2,
  ManualPropulsion = 1u << 3,
  ManualAll = ManualLeft | ManualRight | ManualRear | ManualPropulsion
};

struct __attribute__((packed)) HeadingTargetPayload {
  uint8_t protocolVersion, reserved[3];
  uint32_t requestId, commandSequence;
  uint64_t sourceUs;
  float targetYawRad;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) RuntimeTuningCommandPayload {
  uint8_t protocolVersion, reserved[3];
  uint32_t requestId, commandSequence;
  uint64_t sourceUs;
  float kpPitch, kdPitch, kpRoll, kdRoll, pitchCommandCutoffHz, rollCommandCutoffHz,
      heightCommandCutoffHz, yawCommandCutoffHz, kpHeight, kpYaw, kdYaw, targetHeightM, maxDuty,
      vescRampRiseSeconds;
  float leftUpDeg, leftMiddleDeg, leftDownDeg;
  float rightUpDeg, rightMiddleDeg, rightDownDeg;
  float rearLeftDeg, rearMiddleDeg, rearRightDeg;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) ControlCommandAckPayload {
  uint32_t requestId, commandSequence;
  uint8_t commandType, disposition, safetyState, controlMode;
  uint16_t reason, reserved;
  uint64_t receivedUs, appliedUs;
  uint32_t canonicalCrc;
};

static_assert(sizeof(ControlModeCommandPayload) == 24, "ControlModeCommandPayload size");
static_assert(sizeof(ManualCommandPayload) == 40, "ManualCommandPayload size");
static_assert(sizeof(HeadingTargetPayload) == 28, "HeadingTargetPayload size");
static_assert(sizeof(RuntimeTuningCommandPayload) == 116, "RuntimeTuningCommandPayload size");
static_assert(sizeof(ControlCommandAckPayload) == 36, "ControlCommandAckPayload size");
static_assert(sizeof(ControlSnapshotPayload) == 198, "ControlSnapshotPayload size");
static_assert(sizeof(InaStatusPayload) == 32, "InaStatusPayload size");
static_assert(sizeof(VescTelemetryPayload) == 48, "VescTelemetryPayload size");
static_assert(sizeof(ActuatorStatePayload) == 36, "ActuatorStatePayload size");
static_assert(sizeof(SystemHealthPayload) == 36, "SystemHealthPayload size");
static_assert(sizeof(WaypointSetPayload) == 276, "WaypointSetPayload size");
static_assert(sizeof(WaypointAckPayload) == 16, "WaypointAckPayload size");

struct __attribute__((packed)) ProvisionalSystemPayload {
  uint64_t estimateUs;
  float rollRad, pitchRad, yawRad;
  float rollRateRadS, pitchRateRadS, yawRateRadS;
  double latitudeDeg, longitudeDeg;
  float groundSpeedMps, courseRad, waterHeightM;
  float accelDeltaMps2, gyroDeltaRadS;
  uint32_t primaryAgeMs, secondaryAgeMs, gnssAgeMs, tofAgeMs;
  uint16_t tofCenterMm;
  uint8_t flags, virtualMode, reserved[2];
};
enum class CalibrationKind : uint8_t {
  Static6Face = 1,
  RotationX = 2,
  RotationY = 3,
  RotationZ = 4,
  GyroBias = 5,
  Magnetic = 6,
  TimeOffset = 7,
  Tof = 8,
  ServoGeometry = 9,
  VescTelemetry = 10
};
enum class CalibrationAction : uint8_t { Start = 1, Stop = 2 };

struct __attribute__((packed)) CalibrationMarkerPayload {
  uint32_t sessionId;
  uint8_t kind, action, step, reserved;
};

struct __attribute__((packed)) TimingDiagnosticPayload {
  uint32_t originBootId, originSequence;
  uint8_t sourceType, bnoSequence;
  uint16_t reserved;
  uint64_t sensorTimestamp, callbackUs, queuePushUs, frameUs, uartRxUs, logQueueUs, sdTaskUs,
      lastSdWriteStartUs, lastSdWriteEndUs;
  uint32_t queueWaitUs;
};
enum class EstimateHealth : uint8_t { Invalid = 0, Degraded = 1, Valid = 2 };

enum EstimatedStateFlag : uint8_t {
  EstimateAccelCorrection = 1u << 0,
  EstimateMagCorrection = 1u << 1,
  EstimateGnssYawCorrection = 1u << 2,
  EstimateMountValidated = 1u << 3
};

struct __attribute__((packed)) EstimatedStatePayload {
  uint64_t estimateUs;
  float qw, qx, qy, qz;
  float rollRad, pitchRad, yawRad;
  float rollRateRadS, pitchRateRadS, yawRateRadS;
  float gyroBiasX, gyroBiasY, gyroBiasZ;
  double latitudeDeg, longitudeDeg;
  float groundSpeedMps, courseOverGroundRad, sideslipEstimateRad, waterDistanceM;
  uint32_t gyroAgeUs, accelAgeUs, magAgeUs, gnssAgeUs, tofAgeUs;
  uint8_t attitudeHealth, yawHealth, navigationHealth, heightHealth, flags, reserved[3];
};
enum class P1CaptureAction : uint8_t { Start = 1, Stop = 2 };

struct __attribute__((packed)) P1CapturePayload {
  uint32_t captureId;
  uint8_t action, reserved[3];
};

struct __attribute__((packed)) P1CaptureAckPayload {
  uint32_t captureId;
  uint8_t action, status;
  uint16_t reserved;
  uint32_t firstSequence, lastSequence;
};

struct __attribute__((packed)) GnssNavV2Payload {
  uint32_t navSequence, fixSequence, flags, utcCentiseconds;
  int32_t latitudeE7, longitudeE7, altitudeMm, speedMmPerSec, courseE5Deg;
  uint16_t hdopCenti, satellites;
  uint8_t fixType, reserved[3];
  uint64_t generatedUs, measurementUs;
  uint32_t sourceBootId, canonicalCrc;
};

struct __attribute__((packed)) TimeSyncEstimatePayload {
  uint32_t sequence;
  int64_t offsetUs;
  uint32_t rttUs, uncertaintyUs;
  uint64_t updatedUs;
};

static_assert(sizeof(GnssNavV2Payload) <= kMaxPayload, "GNSS v2 exceeds UART payload");
uint32_t crc32(const uint8_t *, size_t);

enum NavFlag : uint32_t {
  NavFixValid = 1u << 0,
  NavNewFix = 1u << 1,
  NavLatValid = 1u << 2,
  NavLonValid = 1u << 3,
  NavAltitudeValid = 1u << 4,
  NavSpeedValid = 1u << 5,
  NavCourseValid = 1u << 6,
  NavHdopValid = 1u << 7
};

struct __attribute__((packed)) HeartbeatPayload {
  uint32_t uptimeMs, sequence;
  uint8_t safetyState, dryRun;
  uint16_t reserved;
};

struct __attribute__((packed)) GnssNavPayload {
  uint32_t navSequence, fixSequence, flags, utcCentiseconds;
  int32_t latitudeE7, longitudeE7, altitudeMm, speedMmPerSec, courseE5Deg;
  uint16_t hdopCenti, satellites;
  uint8_t fixType, reserved[3];
  uint64_t generatedUs;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) GnssProcessResultPayload {
  uint32_t navSequence, fixSequence, navCanonicalCrc, flags;
  uint64_t controlReceivedUs, controlSentUs;
  int32_t originLatitudeE7, originLongitudeE7, northMm, eastMm;
  int32_t speedMmPerSec, courseMilliRad;
  uint16_t errorCode, safetyState;
  uint8_t dryRun, reserved[3];
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) CommandPayload {
  uint32_t commandId;
  uint8_t commandType;
  uint8_t reserved[3];
};

struct __attribute__((packed)) CommandAckPayload {
  uint32_t commandId;
  uint8_t commandType, disposition, safetyState, dryRun;
  uint64_t receivedUs, appliedUs;
  uint16_t reason, reserved;
};

struct __attribute__((packed)) TimeSyncRequestPayload {
  uint32_t sequence;
  uint64_t t1Us;
};

struct __attribute__((packed)) TimeSyncReplyPayload {
  uint32_t sequence;
  uint64_t t1Us, t2Us, t3Us;
};
enum class BenchmarkPhase : uint8_t {
  Baseline,
  InaCurrent,
  InaBalanced,
  InaFast,
  Tof8x8_10,
  Tof8x8_15,
  Tof4x4_15,
  Tof4x4_30,
  I2c400k,
  I2c100k,
  I2cReturn400k,
  UartBase,
  UartExpected,
  UartDouble,
  UartTarget70,
  Composite
};
enum class BenchmarkAction : uint8_t { Prepare = 1, Start = 2, Stop = 3, Abort = 4 };
enum class BenchmarkStatus : uint8_t {
  Pass = 0,
  Warn = 1,
  Fail = 2,
  NotSupported = 3,
  Aborted = 4
};

enum BenchmarkFlag : uint32_t {
  BenchmarkDryRun = 1u << 0,
  BenchmarkPcaOff = 1u << 1,
  BenchmarkVescZero = 1u << 2,
  BenchmarkTofReady = 1u << 3,
  BenchmarkInaReady = 1u << 4,
  BenchmarkSynthetic = 1u << 5,
  BenchmarkEstimatedI2cBytes = 1u << 6
};

struct __attribute__((packed)) BenchmarkCommandPayload {
  uint32_t campaignId;
  uint16_t phaseId;
  uint8_t phase, action;
  uint32_t durationMs, i2cClockHz;
  uint8_t inaProfile, tofProfile, uartProfile, reserved;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) BenchmarkReadyPayload {
  uint32_t campaignId;
  uint16_t phaseId;
  uint8_t status, safetyState;
  uint32_t flags, runtimeI2cHz;
  uint16_t tofResolution, tofHz;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) BenchmarkResultPayload {
  uint32_t campaignId;
  uint16_t phaseId;
  uint8_t phase, status;
  uint32_t flags;
  uint32_t inaReads, inaFresh, inaDuplicates, tofFrames, tofIncomplete, syntheticRx;
  uint32_t i2cTransactions, i2cErrors, maxI2cUs, maxTofReadUs, maxInaReadUs;
  uint32_t linkDrops, freeHeap, minFreeHeap, durationMs, canonicalCrc;
};

struct __attribute__((packed)) BenchmarkEventPayload {
  uint32_t campaignId;
  uint16_t phaseId;
  uint8_t code, status;
  uint32_t value, flags;
  uint64_t timestampUs;
  uint32_t canonicalCrc;
};

struct __attribute__((packed)) SyntheticDataPayload {
  uint32_t campaignId, sequence;
  uint16_t stream, bytes;
  uint64_t generatedUs;
  uint8_t pattern[48];
  uint32_t payloadCrc;
};

inline uint32_t canonicalCrc(const void *value, size_t n) {
  return crc32(static_cast<const uint8_t *>(value), n);
}

size_t encode(const Header &, const uint8_t *, uint8_t *, size_t);

class Decoder {
public:
  bool feed(uint8_t, Frame &);
  uint32_t crcErrors = 0, cobsErrors = 0, lengthErrors = 0;

private:
  uint8_t encoded_[kMaxEncoded]{};
  size_t n_ = 0;
};
}
