#pragma once

constexpr char productionSensorsPageJapanese[] = R"HTML(
<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>水上ボート センサーモニタ</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f5f7;color:#18202a;font:16px system-ui,sans-serif}main{max-width:760px;margin:auto;padding:18px}h1{font-size:23px;margin:4px 0 12px}.summary,.panel{background:#fff;border:1px solid #d7dce2;border-radius:10px;padding:13px;margin:12px 0}.summary{font-weight:750;background:#f2f5f8}.summary.ok{background:#dcf3e3}.summary.bad{background:#fde0df}.title{font-weight:800;margin-bottom:9px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.item{border-radius:8px;padding:9px;background:#f2f5f8;min-height:61px}.key{font-size:12px;font-weight:750;color:#59636e}.value{font-weight:800;font-variant-numeric:tabular-nums;overflow-wrap:anywhere;margin-top:3px}.detail{font-size:13px;line-height:1.5;color:#59636e;margin-top:6px}.ok{background:#dcf3e3}.bad{background:#fde0df}@media(max-width:520px){.grid{grid-template-columns:1fr}}
</style><main>
<div style="text-align:right"><a href="/" style="color:#1859a8;font-weight:700">← 制御画面へ</a>　<a href="/track" style="color:#1859a8;font-weight:700">航跡</a>　</div><h1>センサーモニタ</h1>
<div id="summary" class="summary">センサー情報を取得しています…</div>
<section class="panel"><div class="title">BNO08X（姿勢）</div><div id="imu" class="grid"></div></section>
<section class="panel"><div class="title">ToF（水面距離）</div><div id="tof" class="grid"></div></section>

<section class="panel"><div class="title">INA226（電源計測）</div><div id="ina" class="grid"></div></section>
<section class="panel"><div class="title">VESC（モーター）</div><div id="vesc" class="grid"></div></section>
<div class="detail">1秒ごとに更新します。制御側からのINA・VESC詳細も1秒周期で送るため、制御処理への負荷は小さく抑えています。</div>
</main><script>
const $=id=>document.getElementById(id);const n=(v,d=2)=>Number.isFinite(Number(v))?Number(v).toFixed(d):'--';const age=v=>v===4294967295||v==null?'未受信':(Number(v)<1000?Number(v)+' ms':(Number(v)/1000).toFixed(1)+' 秒');const yes=v=>v?'接続・有効':'未接続・無効';
function cell(k,v,ok,detail=''){return '<div class="item '+(ok?'ok':'bad')+'"><div class="key">'+k+'</div><div class="value">'+v+'</div>'+(detail?'<div class="detail">'+detail+'</div>':'')+'</div>'}
function render(d){const i=d.imu,t=d.tof,g=d.gnss,p=d.ina,v=d.vesc;$('summary').className='summary '+(d.connected?'ok':'bad');$('summary').textContent=d.connected?'制御側XIAOからセンサー情報を受信しています。':'制御側XIAOとのUART通信を受信できていません。';$('imu').innerHTML=cell('状態',yes(i.valid),i.valid,'最終値 '+age(i.age_ms))+cell('ロール / ピッチ',n(i.roll_deg)+'° / '+n(i.pitch_deg)+'°',i.valid)+cell('ヨー方位',n(i.yaw_deg)+'°',i.valid,'航行の方向制御に使用')+cell('角速度 R / P / Y',n(i.roll_rate_dps)+' / '+n(i.pitch_rate_dps)+' / '+n(i.yaw_rate_dps)+' °/s',i.valid);$('tof').innerHTML=cell('状態',yes(t.valid),t.valid,'最終値 '+age(t.age_ms))+cell('水面距離',n(t.distance_m,3)+' m',t.valid);$('ina').innerHTML=cell('I²C検出',p.detected?'接続済み':'未接続',p.detected)+cell('計測状態',yes(p.valid),p.valid,'最終値 '+age(p.age_ms))+cell('バス電圧',p.valid?n(p.bus_v,3)+' V':'--',p.valid)+cell('電流 / 電力',p.valid?n(p.current_a,3)+' A / '+n(p.power_w,3)+' W':'--',p.valid)+cell('シャント電圧',p.valid?n(p.shunt_v,5)+' V':'--',p.valid);$('vesc').innerHTML=cell('状態',yes(v.valid),v.valid,'最終値 '+age(v.age_ms)+' / Fault '+v.fault)+cell('ERPM / Duty',v.valid?n(v.erpm,1)+' / '+n(v.duty,4):'--',v.valid)+cell('入力電圧',v.valid?n(v.input_v,3)+' V':'--',v.valid)+cell('モーター / 入力電流',v.valid?n(v.motor_current_a,3)+' A / '+n(v.input_current_a,3)+' A':'--',v.valid)+cell('MOS / モーター温度',v.valid?n(v.mos_temp_c,1)+' / '+n(v.motor_temp_c,1)+' °C':'--',v.valid)}
async function load(){try{const r=await fetch('/api/sensors',{cache:'no-store'});if(!r.ok)throw Error();render(await r.json())}catch(e){$('summary').className='summary bad';$('summary').textContent='通信側XIAOからセンサー情報を取得できません。'}}setInterval(load,1000);load();
</script></html>)HTML";
