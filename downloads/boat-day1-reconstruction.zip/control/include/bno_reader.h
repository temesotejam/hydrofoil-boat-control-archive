#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BNO08x.h>
#include <freertos/queue.h>

namespace bno {
enum class EventType : uint8_t {
  Accel = 1,
  Gyro = 2,
  Rotation = 3,
  Magnetic = 4,
  LinearAcceleration = 5
};

struct Sample {
  EventType type;
  uint8_t accuracy = 0, sequence = 0;
  uint64_t rxUs = 0, sensorUs = 0, callbackUs = 0, queuePushUs = 0;
  float v[7]{};
};

struct Rate {
  uint32_t count = 0, missing = 0;
  uint8_t previousSequence = 0;
  uint64_t firstUs = 0, lastUs = 0, previousUs = 0, maxGapUs = 0;

  float hz() const {
    return count > 1 ? 1000000.0f * (count - 1) / (lastUs - firstUs) : 0.0f;
  }

  void add(uint64_t, uint8_t);
};

struct Latest {
  bool accelValid = false, gyroValid = false, rotationValid = false, magneticValid = false;
  float ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0, mx = 0, my = 0, mz = 0, qx = 0, qy = 0,
        qz = 0, qw = 1, roll = 0, pitch = 0, yaw = 0;
  uint64_t accelUs = 0, gyroUs = 0, rotationUs = 0, magneticUs = 0, lastUs = 0;
};

struct TimestampStats {
  uint32_t events = 0, uniqueCount = 0, consecutiveDuplicates = 0, reversals = 0, rollovers = 0;
  bool uniqueExact = true, uniqueOverflow = false, hasPrevious = false;
  uint64_t firstSensorUs = 0, lastSensorUs = 0, firstRxUs = 0, lastRxUs = 0;
  int64_t sensorDeltaSum = 0, sensorDeltaMin = 0, sensorDeltaMax = 0;
  uint64_t rxDeltaSum = 0, rxDeltaMin = 0, rxDeltaMax = 0;
};

struct VectorStats {
  uint32_t events = 0, nonFinite = 0;
  double sum[3]{}, sumSquares[3]{};
  float minimum[3]{}, maximum[3]{};
  double normSum = 0, normSquares = 0;
  float normMin = 0, normMax = 0;
};

struct FeatureResponse {
  bool valid = false;
  int32_t status = 0;
  uint8_t reportId = 0, flags = 0;
  uint16_t changeSensitivity = 0;
  uint32_t requestedIntervalUs = 0, acceptedIntervalUs = 0, batchIntervalUs = 0, sensorSpecific = 0;
  uint64_t requestUs = 0, responseUs = 0;
};

struct ReportMetrics {
  uint8_t reportId = 0;
  uint32_t intervalUs = 0, enableSuccess = 0, enableFailure = 0, callbacks = 0, events = 0,
           switchHits = 0, kindConversions = 0, eventQueueDrops = 0, resetReconfig = 0;
  uint64_t firstSensorUs = 0, lastSensorUs = 0, firstRxUs = 0, lastRxUs = 0;
};

struct PipelineMetrics {
  uint32_t initSuccessCount = 0, reinitCount = 0, pollCount = 0, callbackEvents = 0,
           decodeErrors = 0, eventQueueDrops = 0, serviceCalls = 0, maxServiceUs = 0,
           accelCallbacks = 0, gyroCallbacks = 0, rotationCallbacks = 0, magneticCallbacks = 0,
           linearCallbacks = 0, otherCallbacks = 0, accelEvents = 0, gyroEvents = 0,
           rotationEvents = 0, magneticEvents = 0, linearEvents = 0, unknownSensorEvents = 0;
  uint16_t eventQueueHighWater = 0;
  uint64_t lastAccelRxUs = 0, lastGyroRxUs = 0, lastRotationRxUs = 0, lastMagneticRxUs = 0,
           lastLinearRxUs = 0, lastAccelSensorUs = 0, lastGyroSensorUs = 0,
           lastRotationSensorUs = 0, lastMagneticSensorUs = 0, lastLinearSensorUs = 0;
  ReportMetrics report[6]{};
  TimestampStats timestamp[3]{};
  VectorStats vector[3]{};
};

class Reader {
public:
  bool begin();
  void poll(void (*)(const Sample &));
  void recover();

  bool ready() const {
    return ready_;
  }

  uint8_t address() const {
    return address_;
  }

  uint32_t reinitCount() const {
    return reinitCount_;
  }

  const char *fault() const {
    return fault_;
  }

  const Latest &latest() const {
    return latest_;
  }

  const Rate &accelRate() const {
    return accelRate_;
  }

  const Rate &gyroRate() const {
    return gyroRate_;
  }

  const Rate &rotationRate() const {
    return rotationRate_;
  }

  const Rate &magneticRate() const {
    return magneticRate_;
  }

  const Rate &linearRate() const {
    return linearRate_;
  }

  PipelineMetrics metrics() const;
  void resetRunStats();
  void requestFeatureSnapshot();

private:
  enum class FeaturePhase : uint8_t { Initial = 1, Reset = 2, Snapshot = 3 };
  static constexpr uint16_t kUniqueTimestampCapacity = 8192;

  struct QueuedEvent {
    sh2_SensorValue_t value{};
    uint64_t rxUs = 0, queuePushUs = 0;
  };

  static void sensorCallback(void *, sh2_SensorEvent_t *);
  void onSensorEvent(sh2_SensorEvent_t *);
  bool registerCallback();
  bool enableReports(FeaturePhase phase = FeaturePhase::Initial);
  bool enableOne(uint8_t, uint8_t, uint32_t, FeaturePhase);
  void queryFeature(uint8_t, uint8_t, FeaturePhase, bool);
  void queryAllFeatures(FeaturePhase);
  bool init();
  bool initialiseTimestampSets();
  void clearTimestampSets();
  void recordTimestamp(uint8_t, uint64_t, uint64_t);
  void recordVector(uint8_t, const float *);
  void handle(const QueuedEvent &, void (*)(const Sample &));
  void setFault(const char *);
  Adafruit_BNO08x sensor_{-1};
  QueueHandle_t eventQueue_ = nullptr;
  bool ready_ = false;
  volatile bool featureSnapshotRequested_ = false;
  uint8_t address_ = 0;
  uint32_t lastReinitMs_ = 0, reinitCount_ = 0;
  char fault_[48] = "not initialized";
  Latest latest_{};
  Rate accelRate_{}, gyroRate_{}, rotationRate_{}, magneticRate_{}, linearRate_{};
  uint64_t *uniqueTimestampSet_[3]{};
  uint8_t *uniqueTimestampUsed_[3]{};
  mutable portMUX_TYPE metricsMux_ = portMUX_INITIALIZER_UNLOCKED;
  PipelineMetrics metrics_{};
};
}