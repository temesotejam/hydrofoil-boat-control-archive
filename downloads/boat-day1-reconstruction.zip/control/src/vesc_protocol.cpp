#include "vesc_protocol.h"
#include <cstring>

namespace vesc {
namespace {
int16_t i16(const uint8_t *p) {
  return (int16_t)((p[0] << 8) | p[1]);
}

int32_t i32(const uint8_t *p) {
  return (int32_t)(((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]);
}
}

uint16_t Parser::crc16(const uint8_t *d, size_t n) {
  uint16_t c = 0;
  while (n--) {
    c ^= (uint16_t)(*d++) << 8;
    for (uint8_t i = 0; i < 8; i++)
      c = (c & 0x8000) ? (uint16_t)((c << 1) ^ 0x1021) : (uint16_t)(c << 1);
  }
  return c;
}

void Parser::reset() {
  state_ = State::Start;
  expected_ = index_ = 0;
  frame_ = {};
  lastByteUs_ = 0;
}

bool Parser::timeout(uint64_t now, ParseError &e) {
  if (state_ != State::Start && lastByteUs_ &&
      (now - lastByteUs_) > (uint64_t)app_config::kVescFrameTimeoutMs * 1000ULL) {
    reset();
    e = ParseError::Timeout;
    return true;
  }
  return false;
}

bool Parser::feed(uint8_t b, uint64_t now, Frame &out, ParseError &e) {
  e = ParseError::None;
  lastByteUs_ = now;
  switch (state_) {
  case State::Start:
    if (b == 2 || b == 3) {
      frame_ = {};
      frame_.start = b;
      state_ = b == 2 ? State::LengthShort : State::LengthLongHi;
    }
    return false;
  case State::LengthShort:
    expected_ = b;
    break;
  case State::LengthLongHi:
    expected_ = (uint16_t)b << 8;
    state_ = State::LengthLongLo;
    return false;
  case State::LengthLongLo:
    expected_ |= b;
    break;
  case State::Payload:
    frame_.payload[index_++] = b;
    if (index_ < expected_)
      return false;
    state_ = State::CrcHi;
    return false;
  case State::CrcHi:
    frame_.receivedCrc = (uint16_t)b << 8;
    state_ = State::CrcLo;
    return false;
  case State::CrcLo:
    frame_.receivedCrc |= b;
    state_ = State::End;
    return false;
  case State::End:
    frame_.endOk = b == 3;
    frame_.payloadLength = expected_;
    frame_.receivedUs = now;
    frame_.calculatedCrc = crc16(frame_.payload, expected_);
    frame_.crcOk = frame_.calculatedCrc == frame_.receivedCrc;
    if (expected_)
      frame_.command = frame_.payload[0];
    out = frame_;
    if (!frame_.endOk)
      e = ParseError::End;
    else if (!frame_.crcOk)
      e = ParseError::Crc;
    reset();
    return true;
  }
  if (expected_ == 0 || expected_ > app_config::kVescMaxPayloadBytes) {
    e = ParseError::Length;
    reset();
    return false;
  }
  index_ = 0;
  state_ = State::Payload;
  return false;
}

bool Parser::parseFirmware(const Frame &f, FirmwareInfo &o) {
  o = {};
  if (!f.crcOk || !f.endOk || f.command != kCommFwVersion || f.payloadLength < 4)
    return false;
  o.major = f.payload[1];
  o.minor = f.payload[2];
  size_t i = 3, n = 0;
  while (i < f.payloadLength && f.payload[i] && n < sizeof(o.hardwareName) - 1)
    o.hardwareName[n++] = (char)f.payload[i++];
  o.hardwareName[n] = 0;
  if (i >= f.payloadLength || f.payload[i++] != 0)
    return false;
  if (f.payloadLength >= i + 12) {
    memcpy(o.uuid, f.payload + i, 12);
    o.uuidValid = true;
    i += 12;
  }
  if (f.payloadLength >= i + 8) {
    i += 8;
    size_t m = 0;
    while (i < f.payloadLength && f.payload[i] && m < sizeof(o.firmwareName) - 1)
      o.firmwareName[m++] = (char)f.payload[i++];
    o.firmwareName[m] = 0;
  }
  o.valid = true;
  return true;
}

bool Parser::parseCurrentValues(const Frame &f, Values &o) {
  o = {};
  if (!f.crcOk || !f.endOk || f.command != kCommGetValues || f.payloadLength != 74)
    return false;
  const uint8_t *p = f.payload + 1;
  o.mosTempC = i16(p) / 10.f;
  p += 2;
  o.motorTempC = i16(p) / 10.f;
  p += 2;
  o.motorCurrentA = i32(p) / 100.f;
  p += 4;
  o.inputCurrentA = i32(p) / 100.f;
  p += 4;
  p += 8;
  o.duty = i16(p) / 1000.f;
  p += 2;
  o.erpm = (float)i32(p);
  p += 4;
  o.inputVoltageV = i16(p) / 10.f;
  p += 2;
  o.ampHours = i32(p) / 10000.f;
  p += 4;
  o.ampHoursCharged = i32(p) / 10000.f;
  p += 4;
  o.wattHours = i32(p) / 10000.f;
  p += 4;
  o.wattHoursCharged = i32(p) / 10000.f;
  p += 4;
  o.tachometer = i32(p);
  p += 4;
  o.tachometerAbs = i32(p);
  p += 4;
  o.fault = *p;
  o.valid = true;
  return true;
}
}