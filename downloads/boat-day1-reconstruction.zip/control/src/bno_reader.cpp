#include "bno_reader.h"
#include "app_config.h"
#include <esp_timer.h>
#include <esp_heap_caps.h>
#include <math.h>
#include <string.h>
using namespace app_config;

namespace {
TwoWire bnoWire(1);

uint8_t reportKind(uint8_t id) {
  if (id == SH2_ACCELEROMETER)
    return 1;
  if (id == SH2_GYROSCOPE_CALIBRATED)
    return 2;
  if (id == SH2_ROTATION_VECTOR || id == SH2_GAME_ROTATION_VECTOR)
    return 3;
  if (id == SH2_MAGNETIC_FIELD_CALIBRATED)
    return 4;
  if (id == SH2_LINEAR_ACCELERATION)
    return 5;
  return 0;
}
}

namespace bno {
namespace {
uint64_t nowUs() {
  return (uint64_t)esp_timer_get_time();
}

void euler(Latest &x) {
  float n = sqrtf(x.qx * x.qx + x.qy * x.qy + x.qz * x.qz + x.qw * x.qw);
  if (n < 1e-6f)
    return;
  float qx = x.qx / n, qy = x.qy / n, qz = x.qz / n, qw = x.qw / n;
  x.roll = atan2f(2 * (qw * qx + qy * qz), 1 - 2 * (qx * qx + qy * qy)) * 180.0f / M_PI;
  float p = fmaxf(-1.0f, fminf(1.0f, 2 * (qw * qy - qz * qx)));
  x.pitch = asinf(p) * 180.0f / M_PI;
  x.yaw = atan2f(2 * (qw * qz + qx * qy), 1 - 2 * (qy * qy + qz * qz)) * 180.0f / M_PI;
}

uint64_t hashTimestamp(uint64_t x) {
  x ^= x >> 33;
  x *= 0xff51afd7ed558ccdULL;
  x ^= x >> 33;
  x *= 0xc4ceb9fe1a85ec53ULL;
  return x ^ (x >> 33);
}
}

void Rate::add(uint64_t t, uint8_t s) {
  if (count) {
    uint64_t d = t - previousUs;
    if (d > maxGapUs)
      maxGapUs = d;
    missing += (uint8_t)(s - previousSequence - 1);
  } else
    firstUs = t;
  previousUs = lastUs = t;
  previousSequence = s;
  count++;
}

void Reader::setFault(const char *s) {
  snprintf(fault_, sizeof(fault_), "%s", s);
}

PipelineMetrics Reader::metrics() const {
  PipelineMetrics copy{};
  portENTER_CRITICAL(&metricsMux_);
  copy = metrics_;
  portEXIT_CRITICAL(&metricsMux_);
  return copy;
}

bool Reader::initialiseTimestampSets() {
  bool ok = true;
  for (uint8_t i = 0; i < 3; ++i) {
    if (!uniqueTimestampSet_[i])
      uniqueTimestampSet_[i] = (uint64_t *)heap_caps_malloc(
          kUniqueTimestampCapacity * sizeof(uint64_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!uniqueTimestampUsed_[i])
      uniqueTimestampUsed_[i] = (uint8_t *)heap_caps_malloc(kUniqueTimestampCapacity,
                                                            MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!uniqueTimestampSet_[i] || !uniqueTimestampUsed_[i])
      ok = false;
  }
  clearTimestampSets();
  return ok;
}

void Reader::clearTimestampSets() {
  for (uint8_t i = 0; i < 3; ++i) {
    if (uniqueTimestampUsed_[i])
      memset(uniqueTimestampUsed_[i], 0, kUniqueTimestampCapacity);
    metrics_.timestamp[i].uniqueExact = uniqueTimestampSet_[i] && uniqueTimestampUsed_[i];
  }
}

void Reader::recordTimestamp(uint8_t i, uint64_t sensor, uint64_t rx) {
  TimestampStats &t = metrics_.timestamp[i];
  if (!t.events) {
    t.firstSensorUs = sensor;
    t.firstRxUs = rx;
  } else {
    const uint64_t previous = t.lastSensorUs;
    const int64_t ds =
        sensor >= previous
            ? (sensor - previous > INT64_MAX ? INT64_MAX : (int64_t)(sensor - previous))
            : (previous - sensor > INT64_MAX ? INT64_MIN : -(int64_t)(previous - sensor));
    const uint64_t dr = rx - t.lastRxUs;
    if (!ds)
      ++t.consecutiveDuplicates;
    if (ds < 0) {
      ++t.reversals;
      if (previous - sensor > (1ULL << 63))
        ++t.rollovers;
    }
    t.sensorDeltaSum += ds;
    t.rxDeltaSum += dr;
    if (t.events == 1) {
      t.sensorDeltaMin = t.sensorDeltaMax = ds;
      t.rxDeltaMin = t.rxDeltaMax = dr;
    } else {
      if (ds < t.sensorDeltaMin)
        t.sensorDeltaMin = ds;
      if (ds > t.sensorDeltaMax)
        t.sensorDeltaMax = ds;
      if (dr < t.rxDeltaMin)
        t.rxDeltaMin = dr;
      if (dr > t.rxDeltaMax)
        t.rxDeltaMax = dr;
    }
  }
  ++t.events;
  t.lastSensorUs = sensor;
  t.lastRxUs = rx;
  if (!uniqueTimestampSet_[i] || !uniqueTimestampUsed_[i]) {
    t.uniqueExact = false;
    return;
  }
  const uint16_t mask = kUniqueTimestampCapacity - 1;
  uint16_t slot = (uint16_t)(hashTimestamp(sensor) & mask);
  for (uint16_t probe = 0; probe < kUniqueTimestampCapacity; ++probe) {
    if (!uniqueTimestampUsed_[i][slot]) {
      uniqueTimestampUsed_[i][slot] = 1;
      uniqueTimestampSet_[i][slot] = sensor;
      ++t.uniqueCount;
      return;
    }
    if (uniqueTimestampSet_[i][slot] == sensor)
      return;
    slot = (slot + 1) & mask;
  }
  t.uniqueExact = false;
  t.uniqueOverflow = true;
}

void Reader::recordVector(uint8_t i, const float *v) {
  VectorStats &s = metrics_.vector[i];
  bool good = true;
  for (uint8_t a = 0; a < 3; ++a)
    if (!isfinite(v[a]))
      good = false;
  if (!good) {
    ++s.nonFinite;
    return;
  }
  const float norm = sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
  if (!s.events) {
    for (uint8_t a = 0; a < 3; ++a)
      s.minimum[a] = s.maximum[a] = v[a];
    s.normMin = s.normMax = norm;
  }
  for (uint8_t a = 0; a < 3; ++a) {
    s.sum[a] += v[a];
    s.sumSquares[a] += (double)v[a] * v[a];
    if (v[a] < s.minimum[a])
      s.minimum[a] = v[a];
    if (v[a] > s.maximum[a])
      s.maximum[a] = v[a];
  }
  s.normSum += norm;
  s.normSquares += (double)norm * norm;
  if (norm < s.normMin)
    s.normMin = norm;
  if (norm > s.normMax)
    s.normMax = norm;
  ++s.events;
}

void Reader::queryFeature(uint8_t kind, uint8_t reportId, FeaturePhase phase, bool afterSet) {
  FeatureResponse f{};
  f.reportId = reportId;
  f.requestUs = nowUs();
  portENTER_CRITICAL(&metricsMux_);
  f.requestedIntervalUs = metrics_.report[kind].intervalUs;
  portEXIT_CRITICAL(&metricsMux_);
  sh2_SensorConfig_t config{};
  f.status = sh2_getSensorConfig((sh2_SensorId_t)reportId, &config);
  f.responseUs = nowUs();
  if (f.status == SH2_OK) {
    f.valid = true;
    f.acceptedIntervalUs = config.reportInterval_us;
    f.batchIntervalUs = config.batchInterval_us;
    f.sensorSpecific = config.sensorSpecific;
    f.changeSensitivity = config.changeSensitivity;
    if (config.changeSensitivityRelative)
      f.flags |= 1;
    if (config.changeSensitivityEnabled)
      f.flags |= 2;
    if (config.wakeupEnabled)
      f.flags |= 4;
    if (config.alwaysOnEnabled)
      f.flags |= 8;
  }
  Serial.printf(
      "BNO_FEATURE phase=%s point=%s kind=%u report_id=%u status=%ld request_us=%llu response_us=%llu requested_interval_us=%lu accepted_interval_us=%lu requested_hz=%.3f accepted_hz=%.3f flags=0x%02X change_sensitivity=%u batch_interval_us=%lu sensor_specific=%lu\n",
      phase == FeaturePhase::Initial ? "initial"
                                     : (phase == FeaturePhase::Reset ? "reset" : "snapshot"),
      afterSet ? "after_set" : "after_all",
      kind,
      reportId,
      (long)f.status,
      (unsigned long long)f.requestUs,
      (unsigned long long)f.responseUs,
      (unsigned long)f.requestedIntervalUs,
      (unsigned long)f.acceptedIntervalUs,
      f.requestedIntervalUs ? 1000000.0 / (double)f.requestedIntervalUs : 0.0,
      f.acceptedIntervalUs ? 1000000.0 / (double)f.acceptedIntervalUs : 0.0,
      f.flags,
      (unsigned)f.changeSensitivity,
      (unsigned long)f.batchIntervalUs,
      (unsigned long)f.sensorSpecific);
}

void Reader::queryAllFeatures(FeaturePhase phase) {
  for (uint8_t kind = 1; kind <= 5; ++kind) {
    uint8_t reportId = 0;
    portENTER_CRITICAL(&metricsMux_);
    reportId = metrics_.report[kind].reportId;
    portEXIT_CRITICAL(&metricsMux_);
    if (reportId)
      queryFeature(kind, reportId, phase, false);
  }
}

void Reader::requestFeatureSnapshot() {
  featureSnapshotRequested_ = true;
}

bool Reader::enableOne(uint8_t kind, uint8_t reportId, uint32_t intervalUs, FeaturePhase phase) {
  const bool ok = sensor_.enableReport(reportId, intervalUs);
  if (kind >= 1 && kind <= 5) {
    portENTER_CRITICAL(&metricsMux_);
    ReportMetrics &r = metrics_.report[kind];
    r.reportId = reportId;
    r.intervalUs = intervalUs;
    if (ok)
      ++r.enableSuccess;
    else
      ++r.enableFailure;
    portEXIT_CRITICAL(&metricsMux_);
    if (ok)
      queryFeature(kind, reportId, phase, true);
  }
  return ok;
}

bool Reader::enableReports(FeaturePhase phase) {
  bool ok = true;
#if BOAT_EXPERIMENT == 31
  // Reconstructed day1 profile uses magnetometer-assisted Rotation Vector.
  ok = enableOne(1, SH2_ACCELEROMETER, 10000UL, phase) && ok;
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
  ok = enableOne(3, SH2_ROTATION_VECTOR, kRotationIntervalUs, phase) && ok;
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, kMagneticIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 27
  ok = enableOne(1, SH2_ACCELEROMETER, 10000UL, phase) && ok;
#elif BOAT_EXPERIMENT == 28
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
#elif BOAT_EXPERIMENT == 29
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, 50000UL, phase) && ok;
#elif BOAT_EXPERIMENT == 30
  ok = enableOne(1, SH2_ACCELEROMETER, 10000UL, phase) && ok;
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
  ok = enableOne(3, SH2_GAME_ROTATION_VECTOR, 20000UL, phase) && ok;
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, 50000UL, phase) && ok;
  ok = enableOne(5, SH2_LINEAR_ACCELERATION, 20000UL, phase) && ok;
#elif BOAT_EXPERIMENT == 25
  ok = enableOne(1, SH2_ACCELEROMETER, kAccelGyroIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 26
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, kMagneticIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 18
  ok = enableOne(3, SH2_GAME_ROTATION_VECTOR, kRotationIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 19
  ok = enableOne(5, SH2_LINEAR_ACCELERATION, kAccelGyroIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 20
  ok = enableOne(1, SH2_ACCELEROMETER, kAccelGyroIntervalUs, phase) && ok;
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, kAccelGyroIntervalUs, phase) && ok;
  ok = enableOne(3, SH2_GAME_ROTATION_VECTOR, kRotationIntervalUs, phase) && ok;
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, kMagneticIntervalUs, phase) && ok;
  ok = enableOne(5, SH2_LINEAR_ACCELERATION, kAccelGyroIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 21
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
  ok = enableOne(3, SH2_GAME_ROTATION_VECTOR, 10000UL, phase) && ok;
#elif BOAT_EXPERIMENT == 22
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
  ok = enableOne(1, SH2_ACCELEROMETER, 10000UL, phase) && ok;
#elif BOAT_EXPERIMENT == 23
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
  ok = enableOne(1, SH2_ACCELEROMETER, 10000UL, phase) && ok;
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, kMagneticIntervalUs, phase) && ok;
#elif BOAT_EXPERIMENT == 24
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, 10000UL, phase) && ok;
  ok = enableOne(1, SH2_ACCELEROMETER, 10000UL, phase) && ok;
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, kMagneticIntervalUs, phase) && ok;
  ok = enableOne(3, SH2_GAME_ROTATION_VECTOR, kRotationIntervalUs, phase) && ok;
  ok = enableOne(5, SH2_LINEAR_ACCELERATION, kAccelGyroIntervalUs, phase) && ok;
#else
  ok = enableOne(2, SH2_GYROSCOPE_CALIBRATED, kAccelGyroIntervalUs, phase) && ok;
  ok = enableOne(1, SH2_ACCELEROMETER, kAccelGyroIntervalUs, phase) && ok;
  ok = enableOne(4, SH2_MAGNETIC_FIELD_CALIBRATED, kMagneticIntervalUs, phase) && ok;
#endif
  queryAllFeatures(phase);
  return ok;
}

void Reader::sensorCallback(void *cookie, sh2_SensorEvent_t *event) {
  if (cookie)
    static_cast<Reader *>(cookie)->onSensorEvent(event);
}

void Reader::onSensorEvent(sh2_SensorEvent_t *event) {
  QueuedEvent queued{};
  if (sh2_decodeSensorEvent(&queued.value, event) != SH2_OK) {
    portENTER_CRITICAL(&metricsMux_);
    ++metrics_.decodeErrors;
    portEXIT_CRITICAL(&metricsMux_);
    return;
  }
  queued.rxUs = nowUs();
  const uint8_t kind = reportKind(queued.value.sensorId);
  portENTER_CRITICAL(&metricsMux_);
  ++metrics_.callbackEvents;
  if (kind >= 1 && kind <= 5)
    ++metrics_.report[kind].callbacks;
  switch (kind) {
  case 1:
    ++metrics_.accelCallbacks;
    break;
  case 2:
    ++metrics_.gyroCallbacks;
    break;
  case 3:
    ++metrics_.rotationCallbacks;
    break;
  case 4:
    ++metrics_.magneticCallbacks;
    break;
  case 5:
    ++metrics_.linearCallbacks;
    break;
  default:
    ++metrics_.otherCallbacks;
    break;
  }
  portEXIT_CRITICAL(&metricsMux_);
  queued.queuePushUs = nowUs();
  if (!eventQueue_ || xQueueSend(eventQueue_, &queued, 0) != pdPASS) {
    portENTER_CRITICAL(&metricsMux_);
    ++metrics_.eventQueueDrops;
    if (kind >= 1 && kind <= 5)
      ++metrics_.report[kind].eventQueueDrops;
    portEXIT_CRITICAL(&metricsMux_);
    return;
  }
  UBaseType_t used = uxQueueMessagesWaiting(eventQueue_);
  portENTER_CRITICAL(&metricsMux_);
  if (used > metrics_.eventQueueHighWater)
    metrics_.eventQueueHighWater = used;
  portEXIT_CRITICAL(&metricsMux_);
}

bool Reader::registerCallback() {
  return sh2_setSensorCallback(sensorCallback, this) == SH2_OK;
}

bool Reader::init() {
  ready_ = false;
  address_ = 0;
  if (!eventQueue_) {
    setFault("BNO event queue unavailable");
    return false;
  }
  xQueueReset(eventQueue_);
  bnoWire.begin(kBnoSdaPin, kBnoSclPin, kBnoI2cHz);
  bnoWire.setTimeOut(20);
  uint8_t a = 0;
  for (uint8_t i = 0x08; i < 0x78; i++) {
    bnoWire.beginTransmission(i);
    if (!bnoWire.endTransmission() && (i == kBnoAddress || i == kBnoAlternateAddress)) {
      a = i;
      break;
    }
  }
  if (!a) {
    setFault("BNO08X not detected (0x4A/0x4B)");
    return false;
  }
  if (!sensor_.begin_I2C(a, &bnoWire)) {
    setFault("begin_I2C failed");
    return false;
  }
  if (!registerCallback() || !enableReports()) {
    setFault("callback/report setup failed");
    return false;
  }
  address_ = a;
  ready_ = true;
  latest_.lastUs = nowUs();
  portENTER_CRITICAL(&metricsMux_);
  ++metrics_.initSuccessCount;
  metrics_.reinitCount = reinitCount_;
  portEXIT_CRITICAL(&metricsMux_);
  setFault("none");
  return true;
}

bool Reader::begin() {
  pinMode(kBnoRstPin, OUTPUT);
  digitalWrite(kBnoRstPin, LOW);
  delay(10);
  digitalWrite(kBnoRstPin, HIGH);
  delay(100);
  pinMode(kBnoIntPin, INPUT_PULLUP);
  eventQueue_ = xQueueCreate(kBnoEventQueueDepth, sizeof(QueuedEvent));
  if (!eventQueue_) {
    setFault("BNO event queue allocation failed");
    return false;
  }
  initialiseTimestampSets();
  return init();
}

void Reader::handle(const QueuedEvent &e, void (*out)(const Sample &)) {
  Sample s{};
  s.accuracy = e.value.status & 3;
  s.sequence = e.value.sequence;
  s.rxUs = e.rxUs;
  s.sensorUs = e.value.timestamp;
  s.callbackUs = e.rxUs;
  s.queuePushUs = e.queuePushUs;
  const uint8_t kind = reportKind(e.value.sensorId);
  uint8_t index = 3;
  if (kind == 1) {
    s.type = EventType::Accel;
    index = 0;
    s.v[0] = e.value.un.accelerometer.x;
    s.v[1] = e.value.un.accelerometer.y;
    s.v[2] = e.value.un.accelerometer.z;
    latest_.ax = s.v[0];
    latest_.ay = s.v[1];
    latest_.az = s.v[2];
    latest_.accelValid = true;
    latest_.accelUs = s.rxUs;
    accelRate_.add(s.rxUs, s.sequence);
  } else if (kind == 2) {
    s.type = EventType::Gyro;
    index = 1;
    s.v[0] = e.value.un.gyroscope.x;
    s.v[1] = e.value.un.gyroscope.y;
    s.v[2] = e.value.un.gyroscope.z;
    latest_.gx = s.v[0];
    latest_.gy = s.v[1];
    latest_.gz = s.v[2];
    latest_.gyroValid = true;
    latest_.gyroUs = s.rxUs;
    gyroRate_.add(s.rxUs, s.sequence);
  } else if (kind == 3) {
    s.type = EventType::Rotation;
    if (e.value.sensorId == SH2_ROTATION_VECTOR) {
      s.v[0] = e.value.un.rotationVector.i;
      s.v[1] = e.value.un.rotationVector.j;
      s.v[2] = e.value.un.rotationVector.k;
      s.v[3] = e.value.un.rotationVector.real;
    } else {
      s.v[0] = e.value.un.gameRotationVector.i;
      s.v[1] = e.value.un.gameRotationVector.j;
      s.v[2] = e.value.un.gameRotationVector.k;
      s.v[3] = e.value.un.gameRotationVector.real;
    }
    latest_.qx = s.v[0];
    latest_.qy = s.v[1];
    latest_.qz = s.v[2];
    latest_.qw = s.v[3];
    euler(latest_);
    s.v[4] = latest_.roll;
    s.v[5] = latest_.pitch;
    s.v[6] = latest_.yaw;
    latest_.rotationValid = true;
    latest_.rotationUs = s.rxUs;
    rotationRate_.add(s.rxUs, s.sequence);
  } else if (kind == 5) {
    s.type = EventType::LinearAcceleration;
    s.v[0] = e.value.un.linearAcceleration.x;
    s.v[1] = e.value.un.linearAcceleration.y;
    s.v[2] = e.value.un.linearAcceleration.z;
    linearRate_.add(s.rxUs, s.sequence);
  } else if (kind == 4) {
    s.type = EventType::Magnetic;
    index = 2;
    s.v[0] = e.value.un.magneticField.x;
    s.v[1] = e.value.un.magneticField.y;
    s.v[2] = e.value.un.magneticField.z;
    latest_.mx = s.v[0];
    latest_.my = s.v[1];
    latest_.mz = s.v[2];
    latest_.magneticValid = true;
    latest_.magneticUs = s.rxUs;
    magneticRate_.add(s.rxUs, s.sequence);
  } else {
    portENTER_CRITICAL(&metricsMux_);
    ++metrics_.unknownSensorEvents;
    portEXIT_CRITICAL(&metricsMux_);
    return;
  }
  latest_.lastUs = s.rxUs;
  portENTER_CRITICAL(&metricsMux_);
  ReportMetrics &r = metrics_.report[kind];
  ++r.switchHits;
  ++r.kindConversions;
  ++r.events;
  if (r.events == 1) {
    r.firstSensorUs = s.sensorUs;
    r.firstRxUs = s.rxUs;
  }
  r.lastSensorUs = s.sensorUs;
  r.lastRxUs = s.rxUs;
  if (kind == 1) {
    ++metrics_.accelEvents;
    metrics_.lastAccelRxUs = s.rxUs;
    metrics_.lastAccelSensorUs = s.sensorUs;
  } else if (kind == 2) {
    ++metrics_.gyroEvents;
    metrics_.lastGyroRxUs = s.rxUs;
    metrics_.lastGyroSensorUs = s.sensorUs;
  } else if (kind == 3) {
    ++metrics_.rotationEvents;
    metrics_.lastRotationRxUs = s.rxUs;
    metrics_.lastRotationSensorUs = s.sensorUs;
  } else if (kind == 4) {
    ++metrics_.magneticEvents;
    metrics_.lastMagneticRxUs = s.rxUs;
    metrics_.lastMagneticSensorUs = s.sensorUs;
  } else {
    ++metrics_.linearEvents;
    metrics_.lastLinearRxUs = s.rxUs;
    metrics_.lastLinearSensorUs = s.sensorUs;
  }
  if (index < 3) {
    recordTimestamp(index, s.sensorUs, s.rxUs);
    recordVector(index, s.v);
  }
  portEXIT_CRITICAL(&metricsMux_);
  out(s);
}

void Reader::poll(void (*out)(const Sample &)) {
  if (!ready_)
    return;
  if (featureSnapshotRequested_) {
    featureSnapshotRequested_ = false;
    queryAllFeatures(FeaturePhase::Snapshot);
  }
  if (sensor_.wasReset()) {
    xQueueReset(eventQueue_);
    if (!registerCallback() || !enableReports(FeaturePhase::Reset)) {
      ready_ = false;
      setFault("callback/report re-enable failed");
      return;
    }
    portENTER_CRITICAL(&metricsMux_);
    for (uint8_t k = 1; k <= 5; ++k)
      if (metrics_.report[k].reportId)
        ++metrics_.report[k].resetReconfig;
    portEXIT_CRITICAL(&metricsMux_);
  }
  uint64_t started = nowUs();
  uint8_t calls = 0;
  portENTER_CRITICAL(&metricsMux_);
  ++metrics_.pollCount;
  portEXIT_CRITICAL(&metricsMux_);
  do {
    sh2_service();
    ++calls;
  } while (digitalRead(kBnoIntPin) == LOW && calls < kBnoServiceCallBudget);
  uint32_t elapsed = (uint32_t)(nowUs() - started);
  portENTER_CRITICAL(&metricsMux_);
  metrics_.serviceCalls += calls;
  if (elapsed > metrics_.maxServiceUs)
    metrics_.maxServiceUs = elapsed;
  portEXIT_CRITICAL(&metricsMux_);
  QueuedEvent queued{};
  while (xQueueReceive(eventQueue_, &queued, 0) == pdTRUE)
    handle(queued, out);
}

void Reader::recover() {
  uint32_t n = millis();
  if (ready_ && n - (uint32_t)(latest_.lastUs / 1000) <= kBnoNoDataTimeoutMs)
    return;
  if (n - lastReinitMs_ < kReinitIntervalMs)
    return;
  lastReinitMs_ = n;
  reinitCount_++;
  portENTER_CRITICAL(&metricsMux_);
  metrics_.reinitCount = reinitCount_;
  portEXIT_CRITICAL(&metricsMux_);
  setFault(ready_ ? "BNO data timeout" : "BNO init retry");
  init();
}

void Reader::resetRunStats() {
  accelRate_ = {};
  gyroRate_ = {};
  rotationRate_ = {};
  magneticRate_ = {};
  linearRate_ = {};
  portENTER_CRITICAL(&metricsMux_);
  ReportMetrics configured[6]{};
  for (uint8_t k = 1; k <= 5; ++k)
    configured[k] = metrics_.report[k];
  metrics_ = {};
  for (uint8_t k = 1; k <= 5; ++k) {
    metrics_.report[k].reportId = configured[k].reportId;
    metrics_.report[k].intervalUs = configured[k].intervalUs;
    metrics_.report[k].enableSuccess = configured[k].enableSuccess;
    metrics_.report[k].enableFailure = configured[k].enableFailure;
    metrics_.report[k].resetReconfig = configured[k].resetReconfig;
  }
  clearTimestampSets();
  portEXIT_CRITICAL(&metricsMux_);
}
}
